<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Adminmenu extends Model
{
    //
}
